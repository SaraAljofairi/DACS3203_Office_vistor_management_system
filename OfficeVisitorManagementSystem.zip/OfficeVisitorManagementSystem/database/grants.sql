-- Template. Replace all three password placeholders in a private copy before running it.
CREATE USER 'ovms_app'@'127.0.0.1' IDENTIFIED BY REPLACE_WITH_OVMS_APP_PASSWORD REQUIRE SSL;
CREATE USER 'ovms_setup'@'127.0.0.1' IDENTIFIED BY REPLACE_WITH_OVMS_SETUP_PASSWORD REQUIRE SSL;
CREATE USER 'ovms_retention'@'127.0.0.1' IDENTIFIED BY REPLACE_WITH_OVMS_RETENTION_PASSWORD REQUIRE SSL;
GRANT SELECT ON ovms.users TO 'ovms_app'@'127.0.0.1';
GRANT INSERT (username,password_hash,role) ON ovms.users TO 'ovms_app'@'127.0.0.1';
GRANT INSERT (username,password_hash,role,totp_secret) ON ovms.users TO 'ovms_setup'@'127.0.0.1';
GRANT UPDATE (failures, locked_until, last_totp_step) ON ovms.users TO 'ovms_app'@'127.0.0.1';
GRANT SELECT, INSERT ON ovms.visitors TO 'ovms_app'@'127.0.0.1';
GRANT SELECT, INSERT ON ovms.visits TO 'ovms_app'@'127.0.0.1';
GRANT UPDATE (status, decided_at, pass_hash, pass_expires, checked_in_at, checked_out_at)
    ON ovms.visits TO 'ovms_app'@'127.0.0.1';
GRANT SELECT, INSERT, DELETE ON ovms.blocked_visitors TO 'ovms_app'@'127.0.0.1';
GRANT SELECT, INSERT ON ovms.audit_events TO 'ovms_app'@'127.0.0.1';
GRANT EVENT ON ovms.* TO 'ovms_retention'@'127.0.0.1';
GRANT SELECT (identity_purge_at) ON ovms.visitors TO 'ovms_retention'@'127.0.0.1';
GRANT UPDATE (identity_cipher,identity_last4,identity_purge_at)
    ON ovms.visitors TO 'ovms_retention'@'127.0.0.1';
GRANT INSERT (event_at,event_type,outcome,detail) ON ovms.audit_events TO 'ovms_retention'@'127.0.0.1';
