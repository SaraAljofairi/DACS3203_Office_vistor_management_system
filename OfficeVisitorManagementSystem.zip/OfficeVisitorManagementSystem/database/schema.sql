CREATE DATABASE IF NOT EXISTS ovms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ovms;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(32) NOT NULL UNIQUE,
    password_hash VARCHAR(200) NOT NULL,
    role ENUM('RECEPTIONIST', 'HOST', 'SECURITY_ADMIN') NOT NULL,
    totp_secret VARBINARY(128),
    last_totp_step BIGINT NOT NULL DEFAULT -1,
    failures INT NOT NULL DEFAULT 0,
    locked_until DATETIME,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS visitors (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    identity_cipher VARBINARY(128),
    identity_last4 CHAR(4),
    identity_purge_at DATETIME
);

CREATE TABLE IF NOT EXISTS visits (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    visitor_id BIGINT NOT NULL,
    host_id BIGINT NOT NULL,
    created_by BIGINT NOT NULL,
    visit_date DATE NOT NULL,
    purpose VARCHAR(200) NOT NULL,
    status ENUM('PENDING','APPROVED','REJECTED','CHECKED_IN','CHECKED_OUT') NOT NULL DEFAULT 'PENDING',
    decided_at DATETIME,
    pass_hash BINARY(32) UNIQUE,
    pass_expires DATETIME,
    checked_in_at DATETIME,
    checked_out_at DATETIME,
    FOREIGN KEY (visitor_id) REFERENCES visitors(id),
    FOREIGN KEY (host_id) REFERENCES users(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    INDEX (host_id, status)
);

CREATE TABLE IF NOT EXISTS blocked_visitors (
    fingerprint BINARY(32) PRIMARY KEY,
    reason VARCHAR(200) NOT NULL,
    created_by BIGINT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS audit_events (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    event_at DATETIME NOT NULL,
    actor_id BIGINT,
    event_type VARCHAR(40) NOT NULL,
    visit_id BIGINT,
    outcome VARCHAR(20) NOT NULL,
    detail VARCHAR(200)
);

