USE ovms;
DELIMITER $$
CREATE EVENT IF NOT EXISTS purge_visitor_identity
ON SCHEDULE EVERY 5 MINUTE DO
BEGIN
    DECLARE purged INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    UPDATE visitors SET identity_cipher = NULL, identity_last4 = NULL, identity_purge_at = NULL
    WHERE identity_purge_at <= UTC_TIMESTAMP();
    SET purged = ROW_COUNT();
    IF purged > 0 THEN
        INSERT INTO audit_events(event_at,event_type,outcome,detail)
        VALUES (UTC_TIMESTAMP(),'ID_RETENTION','SUCCESS',CONCAT('Rows cleared: ',purged));
    END IF;
    COMMIT;
END$$
DELIMITER ;
