# Office Visitor Management System

DACS3203 · Secure Software Development · Part 3 implementation

Java 21 · Swing · Maven · XAMPP MariaDB 10.4 · JDBC

## Project files

| File | What it does |
|---|---|
| `Main.java` | Swing sign-in, registration, visit search, host decisions, passes and security administrator screens |
| `OfficeService.java` | Login, role and ownership checks, visit workflows, SQL statements and audit events |
| `Security.java` | Password hashing, encryption, pass hashing and authenticator codes |
| `Database.java` | Configuration and JDBC transactions |
| `SetupAccount.java` | Generates an encryption key and provisions the first staff accounts |
| `database/` | Schema, limited database accounts and scheduled visitor ID deletion |

## Set up XAMPP on Windows

Follow [XAMPP-SETUP.md](XAMPP-SETUP.md) to configure MariaDB, import the project in Eclipse, and create the first staff accounts. To demonstrate host isolation, also run `java -cp $cp ovms.SetupAccount host.two host` from the project folder with the classpath set as shown in the guide.

## Demonstrate the workflows

| Try | Expected result |
|---|---|
| Sign in as reception and register a synthetic visitor for today, assigning `host.one` | A pending visit appears in search. The result shows the last four ID characters. |
| Sign in as `host.two` and search for the visitor | The visit is absent. |
| Sign in as `host.one`, approve one visit and reject a second | Each visit has the matching status in reception search. A decided visit cannot be decided again. |
| As reception, issue a pass for the approved visit and enter its code at check-in | The printable code expires at Qatar midnight. Print submissions appear in the audit log. A second check-in with that code is denied. |
| Try issuing a pass for a pending or rejected visit | Issuance is denied. |
| Check out the checked-in visit | Status becomes checked out. A repeat checkout is denied. |
| As security administrator, add a block for a synthetic ID and try to register it as reception | Registration is denied. The audit screen records the block and the denial. |
| Try five incorrect passwords on a disposable account, then try the correct one | Login stays locked for 15 minutes. |
| Sign in as security administrator, then attempt a sensitive action with the same authenticator code | Re-authentication rejects the used code. A fresh valid code permits the action. |
| Leave the app idle for ten minutes | It returns to sign-in. |
| In a disposable database set a synthetic record's `identity_purge_at` to the past | The search result stops displaying the suffix immediately. The scheduled job runs every five minutes. When it runs, the three identity fields are cleared and the audit log records the purge count. New IDs are due for deletion one hour before the 30-day limit. |

### Design notes

This implementation uses a Swing GUI, a Java service layer and a local MariaDB server accessed through JDBC. The Part 2 document specifies JavaFX, a separate HTTPS server and PostgreSQL. It also specifies per-record encryption keys, certificate and hostname verification, and a hash-chained audit log with an external checkpoint. This implementation uses a single KeyStore-managed AES key, verified JDBC TLS and database grants that make the audit log append-only for the runtime account. The application's MariaDB account has table-specific grants, bootstrap provisioning uses a separate account, and the retention scheduler owns its own credentials. The app rejects common passwords and predictable variants using a local denylist and checks for username-derived passwords. Blocklist changes and overrides use controlled audit values so free-form secrets are excluded from new security event details. The direct JDBC design assumes a trusted workstation and protected configuration. Diagnose connection failures using the application's temporary-directory `ovms-*.log`, which records error categories and SQL state. Keep the config file, authenticator setup keys and database passwords out of Git.

Use the team's private repository for the assignment milestone. Partner review, the `v3-implementation` tag and the later Part 4 assurance evidence are separate course steps.
